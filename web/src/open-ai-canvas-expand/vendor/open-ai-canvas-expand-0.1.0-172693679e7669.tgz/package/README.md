# @open-ai-canvas/expand

供 `open-ai-canvas` 宿主消费的前端扩展包。包只导出页面、组件和接入类型，不创建独立 React 根节点、路由器或全局 Provider。

AI 图片和视频共用纯视图 `GenerationWorkbench`。宿主原 `WorkbenchPage` 通过 `renderSurface` 注入状态、动作和已绑定的组件槽；模型、上传、任务、生成、素材库与 Agent 仍由宿主执行。

```tsx
import { GenerationWorkbench, type GenerationWorkbenchProps } from "@open-ai-canvas/expand";
import "@open-ai-canvas/expand/styles.css";

export function WorkbenchSurface(props: GenerationWorkbenchProps) {
  return <GenerationWorkbench {...props} />;
}
```

React 由宿主提供，CSS 限定在 `.oacx-generation-workbench` 并继承宿主 token。正式宿主使用 `web/src/open-ai-canvas-expand/vendor/` 中的固定归档和锁文件，更新本包后需要重新打包、更新宿主依赖并构建宿主。

生成、任务及素材 API 通过 `createExpandOpenApi(http)` 接入，`http` 由宿主提供，客户端使用相对前缀 `/expand-openapi/v1`。不创建独立 Axios、登录或 Provider。用户级提交键、错误与取消契约见 [集成说明](../docs/tech-docs/integration.md)。

`ExpandPage` / `ExpandHost` 继续保留为未来独立扩展业务的骨架示例，不参与生成链路。其 `get` 仅接受 `/open-ai-canvas-expand` 前缀，宿主客户端补齐 `/api`。

```tsx
import { ExpandPage, type ExpandHost } from "@open-ai-canvas/expand";

const host: ExpandHost = {
  get: (path, options) => http.get(path, { signal: options?.signal }),
  navigate,
  user: { id: currentUser.id, displayName: currentUser.name },
};

export function ExpandRoute() {
  return <ExpandPage host={host} />;
}
```

本包验证：

```sh
bun install --frozen-lockfile
bun run check
```

宿主本地通过相对路径依赖联调时可运行 `bun run dev`，该命令同时监听 ESM 产物和类型声明。正式校验仍使用 `bun run check`。
